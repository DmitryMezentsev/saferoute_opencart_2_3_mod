<?php

$_['text_title'] = 'DDelivery';
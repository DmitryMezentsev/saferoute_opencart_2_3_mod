<?php

$_['text_title'] = 'Доставка DDelivery';